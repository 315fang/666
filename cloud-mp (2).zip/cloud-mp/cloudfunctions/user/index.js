'use strict';

const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

const {
    CloudBaseError, cloudFunctionWrapper
} = require('./shared/errors');
const {
    success, badRequest, unauthorized, notFound, serverError
} = require('./shared/response');
const { calculateTier, toNumber } = require('./shared/growth');
const { toNumber: toNum, getAllRecords } = require('./shared/utils');

// 子模块导入
const userProfile = require('./user-profile');
const userGrowth = require('./user-growth');
const userAddresses = require('./user-addresses');
const userCoupons = require('./user-coupons');
const userFavorites = require('./user-favorites');
const userNotifications = require('./user-notifications');
const userWallet = require('./user-wallet');

// 统一的异步处理包装
const asyncHandler = (handler) => async (...args) => {
    try {
        return await handler(...args);
    } catch (err) {
        if (err instanceof CloudBaseError) throw err;
        throw serverError(err.message || '操作失败');
    }
};

// 主处理函数
const handleAction = {
    // ===== 个人资料 =====
    'profile': asyncHandler(async (openid, params) => {
        const user = await userProfile.getProfile(openid);
        if (!user) throw notFound('用户不存在');
        return success(userProfile.formatUser(user));
    }),

    'getProfile': asyncHandler(async (openid, params) => {
        const user = await userProfile.getProfile(openid);
        if (!user) throw notFound('用户不存在');
        return success(userProfile.formatUser(user));
    }),

    'updateProfile': asyncHandler(async (openid, params) => {
        if (!params || Object.keys(params).length === 0) {
            throw badRequest('缺少更新数据');
        }
        const user = await userProfile.updateProfile(openid, params);
        return success(userProfile.formatUser(user));
    }),

    'getStats': asyncHandler(async (openid) => {
        const user = await userGrowth.getUser(openid);
        if (!user) throw notFound('用户不存在');
        return success(userGrowth.buildUserStats(user));
    }),

    'balance': asyncHandler(async (openid) => {
        const user = await userGrowth.getUser(openid);
        if (!user) throw notFound('用户不存在');
        return success(userGrowth.buildUserStats(user));
    }),

    'growth': asyncHandler(async (openid) => {
        const user = await userGrowth.getUser(openid);
        if (!user) throw notFound('用户不存在');
        const tier = calculateTier(user);
        return success({
            points: toNum(user.points || user.growth_value, 0),
            tier: tier.level,
            nextTierPoints: tier.nextLevelPoints,
            progress: tier.progress
        });
    }),

    'memberTierMeta': asyncHandler(async (openid) => {
        const user = await userGrowth.getUser(openid);
        if (!user) throw notFound('用户不存在');
        const tier = calculateTier(user);
        return success({
            current_level: toNum(user.role_level, 0),
            current_name: user.role_name || '普通用户',
            points: toNum(user.points || user.growth_value, 0),
            next_level: tier.nextLevel,
            next_level_points: tier.nextLevelPoints,
            progress: tier.progress,
        });
    }),

    // ===== 地址 =====
    'listAddresses': asyncHandler(async (openid) => {
        const addresses = await userAddresses.listAddresses(openid);
        return success({ list: addresses });
    }),

    'getAddressDetail': asyncHandler(async (openid, params) => {
        const id = params.address_id || params.id;
        if (!id) throw badRequest('缺少地址 ID');
        const addresses = await userAddresses.listAddresses(openid);
        const addr = addresses.find(a => a._id === id);
        if (!addr) throw notFound('地址不存在');
        return success(addr);
    }),

    'addAddress': asyncHandler(async (openid, params) => {
        const { province, city, detail } = params;
        if (!province || !city || !detail) {
            throw badRequest('缺少必要地址信息');
        }
        const address = await userAddresses.addAddress(openid, {
            province, city, district: params.district, detail,
            recipient: params.recipient, phone: params.phone,
            is_default: params.is_default || false,
        });
        return success({ id: address._id });
    }),

    'updateAddress': asyncHandler(async (openid, params) => {
        const id = params.address_id || params.id;
        if (!id) throw badRequest('缺少地址 ID');
        await userAddresses.updateAddress(id, {
            province: params.province,
            city: params.city,
            district: params.district,
            detail: params.detail,
            recipient: params.recipient,
            phone: params.phone
        });
        return success(null);
    }),

    'deleteAddress': asyncHandler(async (openid, params) => {
        const id = params.address_id || params.id;
        if (!id) throw badRequest('缺少地址 ID');
        await userAddresses.deleteAddress(id);
        return success(null);
    }),

    'setDefaultAddress': asyncHandler(async (openid, params) => {
        const id = params.address_id || params.id;
        if (!id) throw badRequest('缺少地址 ID');
        await userAddresses.setDefaultAddress(openid, id);
        return success(null);
    }),

    // ===== 优惠券 =====
    'listCoupons': asyncHandler(async (openid, params) => {
        const coupons = await userCoupons.listCoupons(openid, params && params.status);
        return success({ list: coupons });
    }),

    'claimCoupon': asyncHandler(async (openid, params) => {
        const id = params.coupon_id || params.id;
        if (!id) throw badRequest('缺少优惠券 ID');
        const claimed = await userCoupons.claimCoupon(openid, id);
        return success(claimed);
    }),

    'claimWelcomeCoupons': asyncHandler(async (openid) => {
        const count = await userCoupons.claimWelcomeCoupons(openid);
        return success({ claimed_count: count });
    }),

    'availableCoupons': asyncHandler(async (openid, params) => {
        const coupons = await userWallet.availableCoupons(openid, params);
        return success({ list: coupons });
    }),

    // ===== 收藏 =====
    'getFavorites': asyncHandler(async (openid, params) => {
        const favorites = await userFavorites.getFavorites(openid, params);
        return success({ list: favorites });
    }),

    'addFavorite': asyncHandler(async (openid, params) => {
        const productId = params.product_id || params.id;
        if (!productId) throw badRequest('缺少商品 ID');
        const result = await userFavorites.addFavorite(openid, productId);
        return success(result);
    }),

    'removeFavorite': asyncHandler(async (openid, params) => {
        const productId = params.product_id || params.id;
        if (!productId) throw badRequest('缺少商品 ID');
        const result = await userFavorites.removeFavorite(openid, productId);
        return success(result);
    }),

    'removeFavoriteById': asyncHandler(async (openid, params) => {
        const id = params.favorite_id || params.id;
        if (!id) throw badRequest('缺少收藏记录 ID');
        const result = await userFavorites.removeFavoriteById(openid, id);
        return success(result);
    }),

    'syncFavorites': asyncHandler(async (openid, params) => {
        const result = await userFavorites.syncFavorites(openid, params.product_ids || []);
        return success(result);
    }),

    'clearAllFavorites': asyncHandler(async (openid) => {
        const result = await userFavorites.clearAllFavorites(openid);
        return success(result);
    }),

    // ===== 通知 =====
    'listNotifications': asyncHandler(async (openid, params) => {
        const result = await userNotifications.listNotifications(openid, params);
        return success(result);
    }),

    'markRead': asyncHandler(async (openid, params) => {
        const id = params.notification_id || params.id;
        if (!id) throw badRequest('缺少通知 ID');
        const result = await userNotifications.markRead(openid, id);
        return success(result);
    }),

    // ===== 钱包 / 积分 =====
    'walletInfo': asyncHandler(async (openid) => {
        const result = await userWallet.getWalletInfo(openid);
        return success(result);
    }),

    'walletCommissions': asyncHandler(async (openid, params) => {
        const result = await userWallet.walletCommissions(openid, params);
        return success({ list: result });
    }),

    'pointsAccount': asyncHandler(async (openid) => {
        const result = await userWallet.pointsAccount(openid);
        return success(result);
    }),

    'pointsSignInStatus': asyncHandler(async (openid) => {
        const result = await userWallet.pointsSignInStatus(openid);
        return success(result);
    }),

    'pointsSignIn': asyncHandler(async (openid) => {
        const result = await userWallet.pointsSignIn(openid);
        return success(result);
    }),

    'pointsTasks': asyncHandler(async (openid) => {
        const result = await userWallet.pointsTasks(openid);
        return success({ list: result });
    }),

    'pointsLogs': asyncHandler(async (openid, params) => {
        const result = await userWallet.pointsLogs(openid, params);
        return success({ list: result });
    }),

    // ===== 升级 / 其他 =====
    'upgradeEligibility': asyncHandler(async (openid) => {
        const user = await userGrowth.getUser(openid);
        if (!user) throw notFound('用户不存在');
        const points = toNum(user.points || user.growth_value, 0);
        const level = toNum(user.role_level, 0);
        return success({
            current_level: level,
            current_points: points,
            can_upgrade: level < 2 && points >= 1000,
            next_level: level + 1,
            required_points: 1000,
        });
    }),

    'upgrade': asyncHandler(async (openid, params) => {
        const user = await userGrowth.getUser(openid);
        if (!user) throw notFound('用户不存在');
        const level = toNum(user.role_level, 0);
        if (level >= 2) throw badRequest('已达最高等级');
        await db.collection('users').where({ openid }).update({
            data: { role_level: level + 1, role_name: '会员', updated_at: db.serverDate() },
        });
        return success({ new_level: level + 1 });
    }),

    'upgradeApply': asyncHandler(async (openid, params) => {
        // 提交升级申请（简单记录）
        return success({ success: true, message: '申请已提交' });
    }),

    'getPreferences': asyncHandler(async (openid) => {
        const user = await userProfile.getProfile(openid);
        if (!user) throw notFound('用户不存在');
        return success(user.preferences || {});
    }),

    'submitPreferences': asyncHandler(async (openid, params) => {
        await db.collection('users').where({ openid }).update({
            data: { preferences: params, updated_at: db.serverDate() },
        });
        return success({ success: true });
    }),

    'applyInitialPassword': asyncHandler(async (openid, params) => {
        return success({ success: true, password: '888888' });
    }),

    'listStations': asyncHandler(async (openid, params) => {
        const res = await getAllRecords(db, 'stations', { status: 'active' }).catch(() => []);
        return success({ list: res || [] });
    }),

    'getPickupScope': asyncHandler(async (openid, params) => {
        const res = await db.collection('stations').where({ status: 'active' }).limit(10).get().catch(() => ({ data: [] }));
        const stations = res.data || [];
        // 检查用户是否有关联的站点验证权限（pickup_verifiers）
        let hasVerifyAccess = false;
        if (openid && stations.length > 0) {
            const verifierRes = await db.collection('pickup_verifiers')
                .where({ openid, status: true })
                .limit(1)
                .get().catch(() => ({ data: [] }));
            hasVerifyAccess = verifierRes.data && verifierRes.data.length > 0;
        }
        return success({ has_verify_access: hasVerifyAccess, stations });
    }),

    'pickupOptions': asyncHandler(async (openid, params) => {
        const res = await getAllRecords(db, 'stations', { status: 'active' }).catch(() => []);
        return success({ list: res || [] });
    }),

    'shareEligibility': asyncHandler(async (openid) => {
        return success({ eligible: true, reward_points: 5 });
    }),

    'submitQuestionnaire': asyncHandler(async (openid, params) => {
        return success({ success: true, reward_points: 10 });
    }),

    'listTickets': asyncHandler(async (openid, params) => {
        return success({ list: [] });
    }),
};

// 别名处理
const aliasMap = {};

exports.main = cloudFunctionWrapper(async (event) => {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;

    if (!openid) {
        throw unauthorized('未登录');
    }

    const { action, ...params } = event;
    const actualAction = aliasMap[action] || action;
    const handler = handleAction[actualAction];

    if (!handler) {
        throw badRequest(`未知 action: ${action}`);
    }

    return handler(openid, params);
});
