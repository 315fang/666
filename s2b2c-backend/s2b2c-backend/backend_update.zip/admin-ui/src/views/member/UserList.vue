<template>
  <div>
    <!-- Filters -->
    <div style="margin-bottom: 20px;">
       <el-input v-model="query.keyword" placeholder="昵称/手机号" style="width: 200px; margin-right: 10px;" />
       <el-button type="primary" @click="handleSearch">搜索</el-button>
    </div>

    <!-- Table -->
    <el-table :data="list" border v-loading="loading">
       <el-table-column prop="id" label="ID" width="80" />
       <el-table-column label="用户信息" width="250">
           <template #default="{ row }">
               <div style="display: flex; align-items: center;">
                   <el-avatar :src="row.avatar_url" style="margin-right: 10px;" />
                   <div>
                       <div>{{ row.nickname }}</div>
                       <div style="font-size: 12px; color: #999;">{{ row.openid?.substring(0, 10) }}...</div>
                   </div>
               </div>
           </template>
       </el-table-column>
       <el-table-column prop="role_level" label="分销等级" width="120">
           <template #default="{ row }">
               <el-tag :type="getRoleType(row.role_level)">{{ getRoleText(row.role_level) }}</el-tag>
           </template>
       </el-table-column>
       <el-table-column prop="balance" label="余额" width="120">
            <template #default="{ row }">¥{{ Number(row.wallet?.balance || 0).toFixed(2) }}</template>
       </el-table-column>
       <el-table-column prop="created_at" label="注册时间" width="180">
            <template #default="{ row }">
                {{ new Date(row.createdAt).toLocaleString() }}
            </template>
       </el-table-column>
       <el-table-column label="操作">
           <template #default="{ row }">
               <el-button link type="primary" @click="showRoleDialog(row)">调整等级</el-button>
           </template>
       </el-table-column>
    </el-table>

    <!-- Pagination -->
    <div style="margin-top: 20px; text-align: right;">
        <el-pagination
            background
            layout="prev, pager, next"
            :total="total"
            :page-size="query.limit"
            @current-change="handlePageChange"
        />
    </div>

    <!-- Role Dialog -->
    <el-dialog v-model="roleDialogVisible" title="调整分销等级" width="400px">
        <el-form label-width="80px">
            <el-form-item label="当前等级">
                <el-tag :type="getRoleType(currentUser?.role_level)">{{ getRoleText(currentUser?.role_level) }}</el-tag>
            </el-form-item>
            <el-form-item label="调整为">
                <el-select v-model="newRoleLevel">
                    <el-option label="普通用户" :value="0" />
                    <el-option label="会员 (LV1)" :value="1" />
                    <el-option label="团长 (LV2)" :value="2" />
                    <el-option label="合伙人 (LV3)" :value="3" />
                </el-select>
            </el-form-item>
        </el-form>
        <template #footer>
            <el-button @click="roleDialogVisible = false">取消</el-button>
            <el-button type="primary" @click="handleUpdateRole">确认</el-button>
        </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { getUsers, updateUserRole } from '@/api/user'
import { ElMessage } from 'element-plus'

const list = ref([])
const total = ref(0)
const loading = ref(false)
const roleDialogVisible = ref(false)
const currentUser = ref(null)
const newRoleLevel = ref(0)

const query = reactive({
    page: 1,
    limit: 10,
    keyword: ''
})

const getRoleText = (level) => {
    const map = { 0: '普通用户', 1: '会员', 2: '团长', 3: '合伙人' }
    return map[level] || '未知'
}

const getRoleType = (level) => {
    const map = { 0: 'info', 1: 'success', 2: 'warning', 3: 'danger' }
    return map[level] || ''
}

const loadData = async () => {
    loading.value = true
    try {
        const res = await getUsers(query)
        list.value = res.list
        total.value = res.pagination.total
    } catch (error) {
        console.error(error)
    } finally {
        loading.value = false
    }
}

const handleSearch = () => {
    query.page = 1
    loadData()
}

const handlePageChange = (val) => {
    query.page = val
    loadData()
}

const showRoleDialog = (row) => {
    currentUser.value = row
    newRoleLevel.value = row.role_level
    roleDialogVisible.value = true
}

const handleUpdateRole = async () => {
    try {
        await updateUserRole(currentUser.value.id, newRoleLevel.value)
        ElMessage.success('操作成功')
        roleDialogVisible.value = false
        loadData()
    } catch (error) {
        console.error(error)
    }
}

onMounted(() => {
    loadData()
})
</script>
