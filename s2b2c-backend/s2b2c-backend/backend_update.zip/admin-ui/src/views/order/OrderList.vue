<template>
  <div>
    <!-- Tabs -->
    <el-tabs v-model="activeTab" @tab-change="handleTabChange">
        <el-tab-pane label="全部订单" name="all" />
        <el-tab-pane label="待付款" name="pending" />
        <el-tab-pane label="待发货" name="paid" />
        <el-tab-pane label="待收货" name="shipped" />
        <el-tab-pane label="已完成" name="completed" />
        <el-tab-pane label="售后中" name="refunding" />
    </el-tabs>

    <!-- Filters -->
    <div style="margin-bottom: 20px;">
        <el-input v-model="query.keyword" placeholder="订单号/买家昵称" style="width: 250px; margin-right: 10px;" />
        <el-button type="primary" @click="handleSearch">搜索</el-button>
    </div>

    <!-- Table -->
    <el-table :data="list" border v-loading="loading">
        <el-table-column prop="order_no" label="订单号" width="180" />
        <el-table-column label="商品" width="300">
             <template #default="{ row }">
                 <div style="display: flex; align-items: center;">
                     <el-image :src="row.product?.images?.[0]" style="width: 50px; height: 50px; margin-right: 10px;" />
                     <div>{{ row.product?.name }}</div>
                 </div>
             </template>
        </el-table-column>
        <el-table-column prop="total_amount" label="实付金额" width="120" />
        <el-table-column label="买家" width="150">
             <template #default="{ row }">
                 {{ row.buyer?.nickname }}
             </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
             <template #default="{ row }">
                 <el-tag>{{ getStatusText(row.status) }}</el-tag>
             </template>
        </el-table-column>
        <el-table-column prop="created_at" label="创建时间" width="180">
            <template #default="{ row }">
                {{ new Date(row.createdAt).toLocaleString() }}
            </template>
        </el-table-column>
        <el-table-column label="操作" fixed="right" width="200">
             <template #default="{ row }">
                 <el-button link type="primary" @click="showDetail(row)">详情</el-button>
                 <el-button v-if="row.status === 'paid'" type="success" size="small" @click="showShipDialog(row)">发货</el-button>
             </template>
        </el-table-column>
    </el-table>

    <!-- Pagination -->
    <div style="margin-top: 20px; text-align: right;">
        <el-pagination
            background
            layout="prev, pager, next"
            :total="total"
            :page-size="query.limit"
            @current-change="handlePageChange"
        />
    </div>

    <!-- Ship Dialog -->
    <el-dialog v-model="shipDialogVisible" title="填写物流信息" width="400px">
        <el-form :model="shipForm" label-width="80px">
            <el-form-item label="物流公司">
                <el-input v-model="shipForm.logistics_company" />
            </el-form-item>
            <el-form-item label="物流单号">
                <el-input v-model="shipForm.tracking_number" />
            </el-form-item>
        </el-form>
        <template #footer>
            <el-button @click="shipDialogVisible = false">取消</el-button>
            <el-button type="primary" @click="handleShip">确认发货</el-button>
        </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { getOrders, shipOrder } from '@/api/order'
import { ElMessage } from 'element-plus'

const list = ref([])
const total = ref(0)
const loading = ref(false)
const activeTab = ref('all')
const shipDialogVisible = ref(false)
const currentOrder = ref(null)

const query = reactive({
    page: 1,
    limit: 10,
    keyword: '',
    status: ''
})

const shipForm = reactive({
    logistics_company: '',
    tracking_number: ''
})

const statusMap = {
    pending: '待付款',
    paid: '待发货',
    shipped: '已发货',
    completed: '已完成',
    refund: '售后中',
    closed: '已关闭'
}

const getStatusText = (status) => statusMap[status] || status

const loadData = async () => {
    loading.value = true
    try {
        const params = { ...query }
        if (activeTab.value !== 'all') {
            params.status = activeTab.value
        }
        const res = await getOrders(params)
        list.value = res.list
        total.value = res.pagination.total
    } catch (error) {
        console.error(error)
    } finally {
        loading.value = false
    }
}

const handleTabChange = () => {
    query.page = 1
    loadData()
}

const handleSearch = () => {
    query.page = 1
    loadData()
}

const handlePageChange = (val) => {
    query.page = val
    loadData()
}

const showDetail = (row) => {
    // TODO: Implement detail dialog or drawer
    console.log(row)
}

const showShipDialog = (row) => {
    currentOrder.value = row
    shipForm.logistics_company = ''
    shipForm.tracking_number = ''
    shipDialogVisible.value = true
}

const handleShip = async () => {
    if (!shipForm.logistics_company || !shipForm.tracking_number) {
        return ElMessage.warning('请填写完整物流信息')
    }
    try {
        await shipOrder(currentOrder.value.id, shipForm)
        ElMessage.success('发货成功')
        shipDialogVisible.value = false
        loadData()
    } catch (error) {
        console.error(error)
    }
}

onMounted(() => {
    loadData()
})
</script>
