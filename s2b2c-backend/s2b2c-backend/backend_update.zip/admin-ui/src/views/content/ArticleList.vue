<template>
  <div style="padding: 20px; text-align: center; color: #999;">
    <h3>图文内容管理</h3>
    <p>该功能正在开发中...</p>
  </div>
</template>

<script setup>
</script>
