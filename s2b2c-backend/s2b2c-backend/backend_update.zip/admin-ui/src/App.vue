<template>
  <router-view />
</template>

<script setup>
</script>

<style>
/* Global resets handled in style.css */
</style>
