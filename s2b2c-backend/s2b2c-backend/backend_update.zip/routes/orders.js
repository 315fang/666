const express = require('express');
const router = express.Router();
const {
    createOrder, payOrder, shipOrder, confirmOrder, cancelOrder,
    getOrders, getOrderById,
    agentConfirmOrder, requestShipping, settleCommissions, getAgentOrders
} = require('../controllers/orderController');
const { authenticate } = require('../middleware/auth');

// POST /api/orders - 创建订单
router.post('/orders', authenticate, createOrder);

// GET /api/orders - 获取订单列表
router.get('/orders', authenticate, getOrders);

// GET /api/orders/agent/list - 代理人获取待处理订单
router.get('/orders/agent/list', authenticate, getAgentOrders);

// GET /api/orders/:id - 获取订单详情
router.get('/orders/:id', authenticate, getOrderById);

// POST /api/orders/:id/pay - 支付订单
router.post('/orders/:id/pay', authenticate, payOrder);

// POST /api/orders/:id/agent-confirm - 代理人确认订单
router.post('/orders/:id/agent-confirm', authenticate, agentConfirmOrder);

// POST /api/orders/:id/request-shipping - 代理人申请发货
router.post('/orders/:id/request-shipping', authenticate, requestShipping);

// POST /api/orders/:id/ship - 管理后台确认发货
router.post('/orders/:id/ship', authenticate, shipOrder);

// POST /api/orders/:id/confirm - 买家确认收货
router.post('/orders/:id/confirm', authenticate, confirmOrder);

// POST /api/orders/:id/cancel - 取消订单
router.post('/orders/:id/cancel', authenticate, cancelOrder);

// POST /api/orders/settle-commissions - 结算到期佣金
router.post('/orders/settle-commissions', authenticate, async (req, res) => {
    const count = await settleCommissions();
    res.json({ code: 0, message: `结算完成，共 ${count} 条佣金记录` });
});

module.exports = router;
