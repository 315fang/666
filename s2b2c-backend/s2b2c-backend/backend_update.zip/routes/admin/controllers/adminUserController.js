const { User, Order, CommissionLog, Dealer } = require('../../../models');
const { Op } = require('sequelize');

// 获取用户列表（含邀请码、库存信息）
const getUsers = async (req, res) => {
    try {
        const { role_level, keyword, page = 1, limit = 20 } = req.query;
        const where = {};

        if (role_level !== undefined) where.role_level = parseInt(role_level);
        if (keyword) {
            where[Op.or] = [
                { nickname: { [Op.like]: `%${keyword}%` } },
                { openid: { [Op.like]: `%${keyword}%` } },
                { invite_code: { [Op.like]: `%${keyword}%` } }
            ];
        }

        const offset = (parseInt(page) - 1) * parseInt(limit);

        const { count, rows } = await User.findAndCountAll({
            where,
            attributes: ['id', 'openid', 'nickname', 'avatar_url', 'role_level', 'balance', 'order_count', 'total_sales', 'stock_count', 'invite_code', 'parent_id', 'agent_id', 'created_at'],
            include: [
                { model: User, as: 'parent', attributes: ['id', 'nickname'], required: false }
            ],
            order: [['created_at', 'DESC']],
            offset,
            limit: parseInt(limit)
        });

        res.json({
            code: 0,
            data: {
                list: rows,
                pagination: { total: count, page: parseInt(page), limit: parseInt(limit) }
            }
        });
    } catch (error) {
        console.error('获取用户列表失败:', error);
        res.status(500).json({ code: -1, message: '获取用户列表失败: ' + error.message });
    }
};

// 获取用户详情
const getUserById = async (req, res) => {
    try {
        const { id } = req.params;
        const user = await User.findByPk(id, {
            include: [
                { model: User, as: 'parent', attributes: ['id', 'nickname'] },
                { model: Dealer, as: 'dealer' }
            ]
        });

        if (!user) {
            return res.status(404).json({ code: -1, message: '用户不存在' });
        }

        // 统计信息
        const orderCount = await Order.count({ where: { buyer_id: id } });
        const teamCount = await User.count({ where: { parent_id: id } });
        const totalCommission = await CommissionLog.sum('amount', { where: { user_id: id } }) || 0;

        res.json({
            code: 0,
            data: {
                ...user.toJSON(),
                stats: { orderCount, teamCount, totalCommission }
            }
        });
    } catch (error) {
        console.error('获取用户详情失败:', error);
        res.status(500).json({ code: -1, message: '获取用户详情失败' });
    }
};

// 更新用户角色
const updateUserRole = async (req, res) => {
    try {
        const { id } = req.params;
        const { role_level } = req.body;

        const user = await User.findByPk(id);
        if (!user) {
            return res.status(404).json({ code: -1, message: '用户不存在' });
        }

        user.role_level = role_level;
        await user.save();

        res.json({ code: 0, message: '角色更新成功' });
    } catch (error) {
        console.error('更新用户角色失败:', error);
        res.status(500).json({ code: -1, message: '更新失败' });
    }
};

// 获取用户团队
const getUserTeam = async (req, res) => {
    try {
        const { id } = req.params;
        const { page = 1, limit = 20 } = req.query;
        const offset = (parseInt(page) - 1) * parseInt(limit);

        const { count, rows } = await User.findAndCountAll({
            where: { parent_id: id },
            attributes: ['id', 'openid', 'nickname', 'avatar_url', 'role_level', 'balance', 'order_count', 'total_sales', 'created_at'],
            order: [['created_at', 'DESC']],
            offset,
            limit: parseInt(limit)
        });

        res.json({
            code: 0,
            data: {
                list: rows,
                pagination: { total: count, page: parseInt(page), limit: parseInt(limit) }
            }
        });
    } catch (error) {
        console.error('获取用户团队失败:', error);
        res.status(500).json({ code: -1, message: '获取失败' });
    }
};

/**
 * 管理代理商云库存（充值/扣减）
 * POST body: { stock_change: 100 } 正数充值，负数扣减
 */
const updateUserStock = async (req, res) => {
    try {
        const { id } = req.params;
        const { stock_change, reason } = req.body;

        const user = await User.findByPk(id);
        if (!user) {
            return res.status(404).json({ code: -1, message: '用户不存在' });
        }

        if (user.role_level < 3) {
            return res.status(400).json({ code: -1, message: '只有代理商（等级>=3）才能管理云库存' });
        }

        const change = parseInt(stock_change);
        if (isNaN(change) || change === 0) {
            return res.status(400).json({ code: -1, message: '库存变化量不能为0' });
        }

        const newStock = (user.stock_count || 0) + change;
        if (newStock < 0) {
            return res.status(400).json({ code: -1, message: '库存不足，无法扣减' });
        }

        await user.update({ stock_count: newStock });

        res.json({
            code: 0,
            data: {
                user_id: user.id,
                nickname: user.nickname,
                old_stock: user.stock_count - change,
                new_stock: newStock,
                change
            },
            message: `库存${change > 0 ? '充值' : '扣减'}成功`
        });
    } catch (error) {
        console.error('更新库存失败:', error);
        res.status(500).json({ code: -1, message: '更新库存失败' });
    }
};

/**
 * 手动设置/重置用户邀请码
 */
const updateUserInviteCode = async (req, res) => {
    try {
        const { id } = req.params;
        const { invite_code } = req.body;

        const user = await User.findByPk(id);
        if (!user) {
            return res.status(404).json({ code: -1, message: '用户不存在' });
        }

        if (invite_code) {
            // 手动设定邀请码，检查唯一性
            if (!/^\d{6}$/.test(invite_code)) {
                return res.status(400).json({ code: -1, message: '邀请码必须为6位数字' });
            }
            const exists = await User.findOne({ where: { invite_code, id: { [Op.ne]: id } } });
            if (exists) {
                return res.status(400).json({ code: -1, message: '该邀请码已被占用' });
            }
            await user.update({ invite_code });
        } else {
            // 自动生成
            let code;
            let found = true;
            let attempts = 0;
            while (found && attempts < 100) {
                code = String(Math.floor(100000 + Math.random() * 900000));
                const dup = await User.findOne({ where: { invite_code: code, id: { [Op.ne]: id } } });
                found = !!dup;
                attempts++;
            }
            await user.update({ invite_code: code });
        }

        await user.reload();
        res.json({
            code: 0,
            data: { user_id: user.id, invite_code: user.invite_code },
            message: '邀请码更新成功'
        });
    } catch (error) {
        console.error('更新邀请码失败:', error);
        res.status(500).json({ code: -1, message: '更新邀请码失败' });
    }
};

module.exports = {
    getUsers,
    getUserById,
    updateUserRole,
    getUserTeam,
    updateUserStock,
    updateUserInviteCode
};