const { CommissionLog, User, Order } = require('../../../models');
const { Op } = require('sequelize');

/**
 * 获取全局佣金/分润记录
 */
const getCommissionLogs = async (req, res) => {
    try {
        const { type, status, user_id, page = 1, limit = 20 } = req.query;
        const where = {};

        if (type) where.type = type;
        if (status) where.status = status;
        if (user_id) where.user_id = user_id;

        const offset = (parseInt(page) - 1) * parseInt(limit);

        const { count, rows } = await CommissionLog.findAndCountAll({
            where,
            include: [
                { model: User, as: 'user', attributes: ['id', 'nickname', 'avatar_url', 'role_level'] },
                { model: Order, as: 'order', attributes: ['id', 'order_no', 'total_amount'] }
            ],
            order: [['created_at', 'DESC']],
            offset,
            limit: parseInt(limit)
        });

        // 统计信息
        const totalAmount = await CommissionLog.sum('amount', { where: { status: 'settled' } }) || 0;
        const frozenAmount = await CommissionLog.sum('amount', { where: { status: 'frozen' } }) || 0;

        res.json({
            code: 0,
            data: {
                list: rows,
                pagination: {
                    total: count,
                    page: parseInt(page),
                    limit: parseInt(limit)
                },
                stats: {
                    totalSettled: totalAmount,
                    totalFrozen: frozenAmount
                }
            }
        });
    } catch (error) {
        console.error('获取分润记录失败:', error);
        res.status(500).json({ code: -1, message: '获取失败' });
    }
};

module.exports = {
    getCommissionLogs
};
