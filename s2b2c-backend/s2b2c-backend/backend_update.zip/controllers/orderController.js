const { Order, Product, SKU, User, Cart, CommissionLog, Notification, sequelize } = require('../models');
const { sendNotification } = require('../models/notificationUtil');
const { Op } = require('sequelize');

// 生成订单号
const generateOrderNo = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const random = String(Math.floor(Math.random() * 1000000)).padStart(6, '0');
    return `ORD${year}${month}${day}${random}`;
};

/**
 * 创建订单（含库存校验 + 数据库事务）
 */
const createOrder = async (req, res) => {
    const t = await sequelize.transaction();
    try {
        const userId = req.user.id;
        const { product_id, sku_id, quantity, address_id, remark } = req.body;

        // 参数校验
        if (!product_id || !quantity || quantity < 1) {
            await t.rollback();
            return res.status(400).json({ code: -1, message: '缺少必要参数' });
        }
        if (!address_id) {
            await t.rollback();
            return res.status(400).json({ code: -1, message: '请选择收货地址' });
        }

        // 查询商品（锁定行，防止并发超卖）
        const product = await Product.findByPk(product_id, { transaction: t, lock: t.LOCK.UPDATE });
        if (!product || product.status !== 1) {
            await t.rollback();
            return res.status(404).json({ code: -1, message: '商品不存在或已下架' });
        }

        // 获取用户身份计算动态价格
        const user = await User.findByPk(userId, { transaction: t });
        const roleLevel = user.role_level || 0;

        let price;
        let stockTarget = product; // 默认用商品库存

        // 如果有 SKU，用 SKU 的价格和库存
        if (sku_id) {
            const sku = await SKU.findOne({ 
                where: { id: sku_id, product_id, status: 1 }, 
                transaction: t, 
                lock: t.LOCK.UPDATE 
            });
            if (!sku) {
                await t.rollback();
                return res.status(404).json({ code: -1, message: '商品规格不存在' });
            }
            price = parseFloat(sku.retail_price);
            if (roleLevel >= 1 && sku.member_price) price = parseFloat(sku.member_price);
            if (roleLevel >= 2 && sku.wholesale_price) price = parseFloat(sku.wholesale_price);
            stockTarget = sku;
        } else {
            price = parseFloat(product.retail_price);
            if (roleLevel === 1) price = parseFloat(product.price_member || product.retail_price);
            else if (roleLevel === 2) price = parseFloat(product.price_leader || product.price_member || product.retail_price);
            else if (roleLevel === 3) price = parseFloat(product.price_agent || product.price_leader || product.price_member || product.retail_price);
        }

        // 库存校验
        if (stockTarget.stock < quantity) {
            await t.rollback();
            return res.status(400).json({ code: -1, message: `库存不足，当前仅剩 ${stockTarget.stock} 件` });
        }

        const total_amount = price * quantity;

        // 扣减库存
        await stockTarget.decrement('stock', { by: quantity, transaction: t });
        // 如果有 SKU 也同步扣商品总库存
        if (sku_id) {
            await product.decrement('stock', { by: quantity, transaction: t });
        }

        // 创建订单
        const order = await Order.create({
            order_no: generateOrderNo(),
            buyer_id: userId,
            product_id,
            sku_id: sku_id || null,
            quantity,
            total_amount,
            actual_price: total_amount,
            address_id,
            remark,
            status: 'pending',
            // 记录订单归属的代理商（用于团队发货和业绩归属）
            agent_id: user.agent_id || null,
            distributor_id: user.parent_id || null,
            distributor_role: user.role_level
        }, { transaction: t });

        await t.commit();

        res.json({
            code: 0,
            data: order,
            message: '订单创建成功'
        });
    } catch (error) {
        await t.rollback();
        console.error('创建订单失败:', error);
        res.status(500).json({ code: -1, message: '创建订单失败' });
    }
};

/**
 * 支付订单 (工厂代发模式)
 * TODO: 上线前必须接入微信支付，当前为模拟流程
 */
const payOrder = async (req, res) => {
    const t = await sequelize.transaction();
    try {
        const userId = req.user.id;
        const { id } = req.params;

        const order = await Order.findOne({
            where: { id, buyer_id: userId },
            transaction: t,
            lock: t.LOCK.UPDATE
        });

        if (!order) {
            await t.rollback();
            return res.status(404).json({ code: -1, message: '订单不存在' });
        }

        if (order.status !== 'pending') {
            await t.rollback();
            return res.status(400).json({ code: -1, message: '订单状态不正确' });
        }

        // 更新订单状态
        order.status = 'paid';
        order.paid_at = new Date();
        await order.save({ transaction: t });

        // ---------------------- 核心：级差分润与升级逻辑 START ----------------------
        const buyer = await User.findByPk(userId, { transaction: t });
        const orderProduct = await Product.findByPk(order.product_id, { transaction: t });

        /**
         * 1. 价格体系 (工厂代发，按等级拿货价计算利差)
         */
        const priceMap = {
            0: parseFloat(orderProduct.retail_price || 299),
            1: parseFloat(orderProduct.price_member || 239),
            2: parseFloat(orderProduct.price_leader || 209),
            3: parseFloat(orderProduct.price_agent || 150)
        };

        /**
         * 2. 级差分润逻辑 (向上所有级差)
         * 遍历上级链条，计算每一段的级差并在平台发货模式下发放
         */
        let currentLevel = buyer.role_level;
        let lastCost = priceMap[currentLevel] || priceMap[0];
        let pRef = buyer.parent_id;

        while (pRef) {
            const p = await User.findByPk(pRef, { transaction: t });
            if (!p) break;

            if (p.role_level > currentLevel) {
                const parentCost = priceMap[p.role_level];
                const profit = (lastCost - parentCost) * order.quantity;

                if (profit > 0) {
                    await CommissionLog.create({
                        order_id: order.id,
                        user_id: p.id,
                        amount: profit,
                        type: 'gap',
                        status: 'frozen',
                        remark: `团队级差利润 (${currentLevel}级 -> ${p.role_level}级)`
                    }, { transaction: t });

                    // 发送通知
                    await sendNotification(
                        p.id,
                        '收益到账提醒',
                        `您的下级产生了一笔新订单，您获得级差收益 ¥${profit.toFixed(2)}。`,
                        'commission',
                        order.id
                    );
                }

                // 更新当前锚点，以便下一级计算
                lastCost = parentCost;
                currentLevel = p.role_level;
            }

            pRef = p.parent_id;
            if (currentLevel === 3) break; // 已到最高级，停止寻找
        }

        /**
         * 3. 身份自动升级
         * 普通用户购买后 -> 升级为会员 (Member)
         */
        if (buyer.role_level === 0) {
            buyer.role_level = 1;
            await buyer.save({ transaction: t });

            // 发送通知
            await sendNotification(
                buyer.id,
                '身份升级成功',
                '由于您已成功下单，系统已自动为您升级为“尊享会员”，邀请好友下单可赚取丰厚回报！',
                'upgrade'
            );
        }
        // ---------------------- 核心：级差分润与升级逻辑 END ----------------------

        // 更新用户累计信息
        await buyer.increment('order_count', { transaction: t });
        await buyer.increment('total_sales', { by: parseFloat(order.total_amount), transaction: t });

        await t.commit();

        res.json({
            code: 0,
            data: order,
            message: '支付成功'
        });
    } catch (error) {
        await t.rollback();
        console.error('支付订单失败:', error);
        res.status(500).json({ code: -1, message: '支付失败' });
    }
};

/**
 * 确认收货（T+7 冻结佣金模式）
 */
const confirmOrder = async (req, res) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;

        const order = await Order.findOne({ where: { id, buyer_id: userId } });
        if (!order) return res.status(404).json({ code: -1, message: '订单不存在' });
        if (order.status !== 'shipped') return res.status(400).json({ code: -1, message: '订单状态不正确' });

        order.status = 'completed';
        order.completed_at = new Date();
        // 设置7天后佣金结算时间
        const settlementDate = new Date();
        settlementDate.setDate(settlementDate.getDate() + 7);
        order.settlement_at = settlementDate;
        await order.save();

        // 佣金保持 frozen 状态，等T+7后定时任务结算
        // 如果订单没有冻结佣金（旧流程），则立即结算
        const logs = await CommissionLog.findAll({ where: { order_id: order.id, status: 'frozen' } });
        if (logs.length === 0) {
            // 兼容旧流程：没有冻结佣金，说明佣金在支付时已生成，直接结算
        }
        // 新流程：佣金保持 frozen，等待 settleCommissions 定时任务处理

        res.json({ code: 0, message: '确认收货成功，佣金将在7天后结算' });
    } catch (error) {
        res.status(500).json({ code: -1, message: '确认收货失败' });
    }
};

/**
 * 代理人确认订单
 * POST /api/orders/:id/agent-confirm
 */
const agentConfirmOrder = async (req, res) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;

        const order = await Order.findOne({ where: { id, agent_id: userId } });
        if (!order) return res.status(404).json({ code: -1, message: '订单不存在或您无权操作' });
        if (order.status !== 'paid') return res.status(400).json({ code: -1, message: '订单需为已支付状态' });

        order.status = 'agent_confirmed';
        order.agent_confirmed_at = new Date();
        await order.save();

        res.json({ code: 0, data: order, message: '代理人已确认订单' });
    } catch (error) {
        console.error('代理人确认订单失败:', error);
        res.status(500).json({ code: -1, message: '确认失败' });
    }
};

/**
 * 代理人申请发货
 * POST /api/orders/:id/request-shipping
 */
const requestShipping = async (req, res) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const { tracking_no } = req.body;

        const order = await Order.findOne({ where: { id, agent_id: userId } });
        if (!order) return res.status(404).json({ code: -1, message: '订单不存在或您无权操作' });
        if (order.status !== 'agent_confirmed') return res.status(400).json({ code: -1, message: '请先确认订单再申请发货' });

        const agent = await User.findByPk(userId);
        if (agent.stock_count < order.quantity) {
            return res.status(400).json({ code: -1, message: '库存不足，无法发货' });
        }

        order.status = 'shipping_requested';
        order.shipping_requested_at = new Date();
        order.tracking_no = tracking_no || null;
        order.fulfillment_partner_id = userId;
        await order.save();

        res.json({ code: 0, data: order, message: '已申请发货，等待后台确认' });
    } catch (error) {
        console.error('申请发货失败:', error);
        res.status(500).json({ code: -1, message: '申请失败' });
    }
};

/**
 * 结算到期佣金（定时任务调用）
 */
const settleCommissions = async () => {
    try {
        const now = new Date();
        const frozenLogs = await CommissionLog.findAll({
            where: {
                status: 'frozen',
                available_at: { [Op.lte]: now }
            }
        });

        for (const log of frozenLogs) {
            log.status = 'settled';
            await log.save();
            await User.increment('balance', {
                by: parseFloat(log.amount),
                where: { id: log.user_id }
            });
        }

        console.log(`佣金结算完成：${frozenLogs.length} 条记录`);
        return frozenLogs.length;
    } catch (error) {
        console.error('佣金结算失败:', error);
        return 0;
    }
};

/**
 * 代理人获取待处理订单
 */
const getAgentOrders = async (req, res) => {
    try {
        const userId = req.user.id;
        const { status, page = 1, limit = 20 } = req.query;
        const offset = (parseInt(page) - 1) * parseInt(limit);

        const where = { agent_id: userId };
        if (status) where.status = status;

        const { count, rows } = await Order.findAndCountAll({
            where,
            include: [
                { model: Product, as: 'product', attributes: ['id', 'name', 'images'] },
                { model: User, as: 'buyer', attributes: ['id', 'nickname'] }
            ],
            order: [['created_at', 'DESC']],
            offset,
            limit: parseInt(limit)
        });

        res.json({ code: 0, data: { list: rows, pagination: { total: count, page, limit } } });
    } catch (error) {
        res.status(500).json({ code: -1, message: '获取失败' });
    }
};

/**
 * 取消订单（仅待付款的可取消，恢复库存）
 */
const cancelOrder = async (req, res) => {
    const t = await sequelize.transaction();
    try {
        const userId = req.user.id;
        const { id } = req.params;

        const order = await Order.findOne({
            where: { id, buyer_id: userId },
            transaction: t,
            lock: t.LOCK.UPDATE
        });

        if (!order) {
            await t.rollback();
            return res.status(404).json({ code: -1, message: '订单不存在' });
        }

        if (order.status !== 'pending') {
            await t.rollback();
            return res.status(400).json({ code: -1, message: '仅待付款订单可取消' });
        }

        // 恢复库存
        const product = await Product.findByPk(order.product_id, { transaction: t });
        if (product) {
            await product.increment('stock', { by: order.quantity, transaction: t });
        }
        if (order.sku_id) {
            const sku = await SKU.findByPk(order.sku_id, { transaction: t });
            if (sku) {
                await sku.increment('stock', { by: order.quantity, transaction: t });
            }
        }

        order.status = 'cancelled';
        await order.save({ transaction: t });

        await t.commit();
        res.json({ code: 0, message: '订单已取消' });
    } catch (error) {
        await t.rollback();
        console.error('取消订单失败:', error);
        res.status(500).json({ code: -1, message: '取消订单失败' });
    }
};

/**
 * 发货（支持代理商团队发货 + 平台发货）
 * - 代理商发货：用自己的云库存发货，扣减库存
 * - 平台发货：由工厂/平台直接发，不扣代理商库存
 */
const shipOrder = async (req, res) => {
    const t = await sequelize.transaction();
    try {
        const { id } = req.params;
        const { fulfillment_type, tracking_no } = req.body;
        // fulfillment_type: 'agent'（代理商发） 或 'platform'（平台发）

        const order = await Order.findOne({
            where: { id },
            transaction: t,
            lock: t.LOCK.UPDATE
        });

        if (!order) {
            await t.rollback();
            return res.status(404).json({ code: -1, message: '订单不存在' });
        }

        if (order.status !== 'paid') {
            await t.rollback();
            return res.status(400).json({ code: -1, message: '仅已支付订单可发货' });
        }

        if (fulfillment_type === 'agent') {
            // 代理商发货 - 扣减代理商云库存
            const agentId = order.agent_id;
            if (!agentId) {
                await t.rollback();
                return res.status(400).json({ code: -1, message: '该订单没有归属代理商' });
            }

            const agent = await User.findByPk(agentId, { transaction: t, lock: t.LOCK.UPDATE });
            if (!agent || agent.role_level < 3) {
                await t.rollback();
                return res.status(400).json({ code: -1, message: '代理商信息异常' });
            }

            if (agent.stock_count < order.quantity) {
                await t.rollback();
                return res.status(400).json({ 
                    code: -1, 
                    message: `代理商云库存不足，当前库存 ${agent.stock_count}，需要 ${order.quantity}` 
                });
            }

            // 扣减代理商云库存
            await agent.decrement('stock_count', { by: order.quantity, transaction: t });

            order.fulfillment_type = 'Agent';
            order.fulfillment_partner_id = agentId;
        } else {
            // 平台发货
            order.fulfillment_type = 'Company';
        }

        order.status = 'shipped';
        order.shipped_at = new Date();
        order.tracking_no = tracking_no || null;
        await order.save({ transaction: t });

        await t.commit();

        res.json({ code: 0, data: order, message: '发货成功' });
    } catch (error) {
        await t.rollback();
        console.error('发货失败:', error);
        res.status(500).json({ code: -1, message: '发货失败' });
    }
};

/**
 * 获取订单列表
 */
const getOrders = async (req, res) => {
    try {
        const userId = req.user.id;
        const { status, page = 1, limit = 20 } = req.query;
        const offset = (parseInt(page) - 1) * parseInt(limit);

        const where = { buyer_id: userId };
        if (status) where.status = status;

        const { count, rows } = await Order.findAndCountAll({
            where,
            include: [{ model: Product, as: 'product', attributes: ['id', 'name', 'images'] }],
            order: [['created_at', 'DESC']],
            offset,
            limit: parseInt(limit)
        });

        res.json({ code: 0, data: { list: rows, pagination: { total: count, page, limit } } });
    } catch (error) {
        res.status(500).json({ code: -1, message: '获取列表失败' });
    }
};

/**
 * 获取订单详情
 */
const getOrderById = async (req, res) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;

        const order = await Order.findOne({
            where: { id, buyer_id: userId },
            include: [
                { model: Product, as: 'product', attributes: ['id', 'name', 'images', 'retail_price'] },
                { model: User, as: 'distributor', attributes: ['id', 'nickname'] }
            ]
        });

        if (!order) {
            return res.status(404).json({ code: -1, message: '订单不存在' });
        }

        // 如果有归属代理商，查询代理商信息
        let agentInfo = null;
        if (order.agent_id) {
            const agent = await User.findByPk(order.agent_id, {
                attributes: ['id', 'nickname', 'invite_code']
            });
            if (agent) {
                agentInfo = {
                    id: agent.id,
                    nickname: agent.nickname,
                    invite_code: agent.invite_code
                };
            }
        }

        const result = order.toJSON();
        result.agent_info = agentInfo;

        res.json({ code: 0, data: result });
    } catch (error) {
        console.error('获取订单详情失败:', error);
        res.status(500).json({ code: -1, message: '获取订单详情失败' });
    }
};

module.exports = {
    createOrder,
    payOrder,
    shipOrder,
    confirmOrder,
    cancelOrder,
    getOrders,
    getOrderById,
    agentConfirmOrder,
    requestShipping,
    settleCommissions,
    getAgentOrders
};
