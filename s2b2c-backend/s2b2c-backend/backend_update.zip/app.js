const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const rateLimit = require('express-rate-limit');
const path = require('path');
const { errorHandler, notFound } = require('./middleware/errorHandler');

// 导入路由
const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
const orderRoutes = require('./routes/orders');
const addressRoutes = require('./routes/addresses');
const distributionRoutes = require('./routes/distribution');
const partnerRoutes = require('./routes/partner');
const userRoutes = require('./routes/users');
const categoryRoutes = require('./routes/categories');
const cartRoutes = require('./routes/cart');
const materialRoutes = require('./routes/materials');
const contentRoutes = require('./routes/content');
const walletRoutes = require('./routes/wallet');
const refundRoutes = require('./routes/refunds');
const dealerRoutes = require('./routes/dealer');
const adminRoutes = require('./routes/admin');
const debugRoutes = require('./routes/debug');

const app = express();

// 中间件
// CORS 配置 - 生产环境限制来源
const corsOptions = {
    origin: process.env.CORS_ORIGINS 
        ? process.env.CORS_ORIGINS.split(',').map(s => s.trim()) 
        : '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'x-openid'],
    credentials: true
};
app.use(cors(corsOptions));
app.use(bodyParser.json({ limit: '10mb' })); // 限制请求体大小
app.use(bodyParser.urlencoded({ extended: true }));

// 接口请求频率限制 - 防止恶意刷接口
const apiLimiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1分钟
    max: 100, // 每个IP每分钟最多100次请求
    message: { code: -1, message: '请求过于频繁，请稍后再试' },
    standardHeaders: true,
    legacyHeaders: false
});
app.use('/api', apiLimiter);

// 登录接口更严格的频率限制
const loginLimiter = rateLimit({
    windowMs: 1 * 60 * 1000,
    max: 10, // 每分钟最多10次登录
    message: { code: -1, message: '登录尝试过于频繁' }
});
app.use('/api/login', loginLimiter);

// CSP 中间件 - 仅管理后台页面需要宽松策略
app.use((req, res, next) => {
    if (req.path.startsWith('/admin') && !req.path.startsWith('/admin/api')) {
        // 管理后台静态页面的 CSP
        res.setHeader("Content-Security-Policy", 
            "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' data: https:;");
    }
    next();
});

// 静态文件 - 管理后台 (Vite 构建版)
app.use('/admin', express.static(path.join(__dirname, 'admin-ui/dist')));

// 根目录重定向到管理后台
app.get('/', (req, res) => {
    res.redirect('/admin/');
});

// 请求日志（开发环境）
if (process.env.NODE_ENV === 'development') {
    app.use((req, res, next) => {
        console.log(`${new Date().toISOString()} ${req.method} ${req.path}`);
        next();
    });
}

// API路由
app.use('/api', authRoutes);
app.use('/api', productRoutes);
app.use('/api', orderRoutes);
app.use('/api', addressRoutes);
app.use('/api', distributionRoutes);
app.use('/api', partnerRoutes);
app.use('/api', userRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/materials', materialRoutes);
app.use('/api/content', contentRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/refunds', refundRoutes);
app.use('/api/dealer', dealerRoutes);

// 后台管理API (使用 /admin/api 避免与静态文件冲突)
app.use('/admin/api', adminRoutes);

// 调试接口
app.use('/api/debug', debugRoutes);

// 健康检查
app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// 404处理
app.use(notFound);

// 错误处理
app.use(errorHandler);

module.exports = app;
