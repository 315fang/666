# 云开发迁移记录

**日期**：2026-04-07  
**任务**：新建 `cloud-mp/` 目录，将小程序完整迁移至微信云开发

---

## 新增文件清单

### 项目根
| 文件 | 说明 |
|------|------|
| `cloud-mp/project.config.json` | 云开发项目配置，新增 `cloudfunctionRoot: "cloudfunctions/"` |
| `cloud-mp/CLOUD_DB_SCHEMA.md` | 云数据库11个集合的字段定义、索引、权限规则 |

### 小程序端（cloud-mp/miniprogram/）
| 文件 | 变更类型 | 核心改动 |
|------|---------|---------|
| `app.js` | 重写 | 新增 `wx.cloud.init()`，移除 `baseUrl` / JWT token |
| `appAuth.js` | 重写 | `wxLogin()` 改为 `wx.cloud.callFunction({ name: 'login' })`，移除 code 换取流程 |
| `appConfig.js` | 重写 | `get('/mini-program-config')` → `callFn('config', { action: 'miniProgramConfig' })` |
| `appPrefetch.js` | 重写 | `get('/page-content/home')` → `callFn('config', { action: 'homeContent' })` |
| `app.json` | 直接复用 | 页面结构不变 |
| `sitemap.json` | 直接复用 | 无变化 |
| `utils/cloud.js` | **新建** | 核心：替代 request.js，封装 `callFn()` / `uploadToCloud()` / `getTempUrls()` |
| `utils/auth.js` | 精简 | 移除 HTTP login，保留 `requireLogin()` / `triggerLogin()` 守卫函数 |
| `utils/favoriteSync.js` | 小改 | `post('/user/favorites/sync')` → `callFn('user', { action: 'syncFavorites' })` |
| `utils/miniProgramConfig.js` | 直接复用 | 纯本地工具，无需改动 |
| `utils/localUserContent.js` | 直接复用 | 纯 wx.storage，无需改动 |
| `pages/user/userDashboard.js` | 重写（**迁移模板**） | 所有 `get()` → `callFn()`，作为其他页面迁移的参考 |

### 云函数（cloud-mp/cloudfunctions/）
| 云函数 | 对应原接口 | 说明 |
|--------|-----------|------|
| `login/` | `POST /login` | openid 自动获取，无需 code；处理新用户注册和邀请码绑定 |
| `user/` | `GET/PUT /user/profile`、`getStats` | 用户资料读写、统计汇总 |
| `products/` | `GET /products`、`/categories`、`/search` | 商品列表/详情/分类/搜索 |
| `cart/` | `GET/POST/PUT/DELETE /cart` | 购物车 CRUD，含库存校验和价格快照 |
| `order/` | `POST /orders`、各状态变更 | 下单（扣库存+清购物车）、查询、取消、确认、评价、退款 |
| `payment/` | `POST /orders/:id/pay` | 预留 wx.cloud.cloudPay 接口；notify 更新订单状态 |
| `distribution/` | `/distribution/overview` 等 | 分销中心、团队、佣金流水、提现、结算触发 |
| `config/` | `/mini-program-config`、`/themes/active` 等 | 读取 configs 集合，服务小程序配置/首页/主题/开屏图 |

---

## 关键架构变化

| 维度 | 旧版（miniprogram/） | 新版（cloud-mp/） |
|------|---------------------|-----------------|
| 鉴权 | JWT Token，后端验证 | openid 自动注入，云函数天然持有 |
| 数据库 | MySQL（自建服务器） | 云数据库（MongoDB-like，在线管理） |
| 文件存储 | 自建 CDN / 腾讯云 COS | 云存储，`wx.cloud.uploadFile()` |
| API 调用 | `wx.request` → HTTPS | `wx.cloud.callFunction()` |
| 服务器 | 需要独立 Node.js 服务 | 无服务器，全托管 |

---

## 待完成事项（上线前必做）

- [ ] **【必做】** 在 `cloud-mp/miniprogram/app.js` 第13行替换 `'your-env-id'` 为真实云环境ID
- [ ] **【必做】** 同步修改 `cloud-mp/miniprogram/config/env.js` 第6行的 `CLOUD_ENV_ID`
- [ ] **【必做】** 在微信开发者工具云开发控制台创建所有数据库集合（参考 `CLOUD_DB_SCHEMA.md`）
- [ ] **【必做】** 逐一上传云函数（右键每个 `cloudfunctions/xxx` 目录 → 上传并部署）
- [ ] 配置支付云函数商户信息（`cloudfunctions/payment/index.js` 中的 TODO 注释处）
- [x] ~~复制 components/、assets/、custom-tab-bar/ 等静态目录~~ — 2026-04-07 完成
- [x] ~~页面 JS 迁移~~ — 2026-04-07 完成（通过兼容层 `utils/request.js` 实现，所有页面零改动）

---

## 页面 JS 迁移模式（快速参考）

```javascript
// ❌ 旧版
const { get, post } = require('../../utils/request');
get('/products', { page: 1 });
post('/orders', payload);

// ✅ 新版
const { callFn } = require('../../utils/cloud');
callFn('products', { action: 'list', page: 1 });
callFn('order',    { action: 'create', ...payload });
```

**云函数 action 速查表**：

| 旧接口 | 云函数 | action |
|--------|--------|--------|
| GET /products | products | list |
| GET /products/:id | products | detail |
| GET /categories | products | categories |
| GET /search | products | search |
| GET /cart | cart | list |
| POST /cart | cart | add |
| PUT /cart/:id | cart | update |
| DELETE /cart/:id | cart | remove |
| POST /orders | order | create |
| GET /orders | order | list |
| GET /orders/:id | order | detail |
| POST /orders/:id/cancel | order | cancel |
| POST /orders/:id/confirm | order | confirm |
| POST /orders/:id/review | order | review |
| GET /refunds | order | refundList |
| POST /refunds | order | applyRefund |
| POST /orders/:id/pay | payment | prepay |
| GET /user/profile | user | getProfile |
| PUT /user/profile | user | updateProfile |
| GET /distribution/overview | distribution | center |
| GET /distribution/team | distribution | team |
| GET /distribution/commission-logs | distribution | commLogs |
| POST /distribution/withdraw | distribution | withdraw |
| GET /mini-program-config | config | miniProgramConfig |
| GET /page-content/home | config | homeContent |
| GET /themes/active | config | activeTheme |
| GET /splash/active | config | splash |
