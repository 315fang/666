# 修复：status 字段类型不匹配导致首页空白

## 问题描述
MySQL 导出的数据中，`status` 字段被 `convert.js` 转换为布尔值 `true`（因为 MySQL 中 tinyint(1) 的 1 被识别为 boolean）。
但云函数中所有查询条件写的是 `status: 1`（数字）。
云数据库是严格类型匹配的，`true !== 1`，所以所有查询结果都是 0 条，导致首页完全空白。

## 修改文件清单

### 1. `cloudfunctions/config/index.js`
- 添加 `const _ = db.command;`
- `miniProgramConfig`: `status: 1` → `status: _.in([true, 1, '1'])`
- `homeContent` page_layouts: `status: 1` → `status: _.in([true, 1, '1'])`
- `homeContent` banners: `status: 1` → `status: _.in([true, 1, '1'])`

### 2. `cloudfunctions/products/index.js`
- `list`: `status: true` → `status: _.in([true, 1, '1'])`（之前已修复）
- `search`: 同上
- `categories`: `status: 1` → `status: _.in([true, 1, '1'])`

## 核心改动点
使用 `_.in([true, 1, '1'])` 同时兼容三种可能的状态值格式，避免类型不匹配导致查询失败。

## 已执行验证命令
- 检查了 banners.json、page_layouts.json、app_configs.json、categories.json 的 status 字段
- 确认全部为 `boolean true`，与云函数中的 `1` 不匹配

## 部署要求
修改后需要重新部署以下云函数：
- `config`（上传并部署：云端安装依赖）
- `products`（上传并部署：云端安装依赖）
