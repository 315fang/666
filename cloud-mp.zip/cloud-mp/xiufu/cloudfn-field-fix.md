# 云函数全量字段修正记录

**日期**：2026-04-07

## 问题

原云函数用的是「猜测字段名」，真实 MySQL 导出字段不同，导致读写全部失败。

## 修正清单（8 个云函数全部重写）

### 核心字段对照（MySQL 真实字段 → 云函数使用）

| 集合 | MySQL 真实字段 | 前端期望字段 | 处理方式 |
|------|---|---|---|
| `users` | `nickname` | `nickName` | format 函数别名 |
| `users` | `avatar_url` | `avatarUrl` | format 函数别名 |
| `users` | `agent_level` | `distributor_level` | format 函数别名 |
| `users` | `balance` | `wallet_balance` | format 函数别名 |
| `users` | `parent_openid` | — | 直接使用 |
| `products` | `retail_price` | `price` | format 函数别名 |
| `products` | `market_price` | `original_price` | format 函数别名 |
| `products` | `manual_weight` | — | orderBy 排序字段 |
| `orders` | `buyer_id` | — | 用于 where 查询（= openid） |
| `orders` | `actual_price` | `pay_amount` | format 函数别名 |
| `orders` | `address_snapshot.receiver_name` | `contact_name` | format 嵌套 |
| `cart_items` | `quantity` | `qty` | format 函数别名 |
| `cart_items` | `user_id` | — | 用于 where 查询（= openid） |
| `addresses` | `receiver_name` | `contact_name` | format 函数别名 |
| `addresses` | `detail` | `detail_address` | format 函数别名 |
| `app_configs` | `config_key/config_value` | 结构化 map | config 云函数组装 |
| `splash_screens` | `is_active` | — | where 查询字段 |
| `banners` | `image_url` | `image` | format 函数别名 |
| `commissions` | `user_id` | — | 用于 where 查询 |

### 各云函数修正要点

| 云函数 | 主要修正 |
|--------|---------|
| `login` | `agent_level`, `role_level`, `avatar_url`, `my_invite_code`, `parent_openid` |
| `user` | `nickname`→nickName, `avatar_url`→avatarUrl, `balance`→wallet_balance, `agent_level`→distributor_level; addresses 用 `receiver_name/detail` |
| `products` | `retail_price`→price, `market_price`→original_price, `manual_weight` 排序, `status=true` 布尔 |
| `cart` | `quantity` (DB) vs `qty` (前端), `user_id`=openid, 集合名 `product_skus` |
| `order` | `buyer_id`=openid, `actual_price`→pay_amount, `address_snapshot` 嵌套 |
| `payment` | `buyer_id`=openid, `actual_price`, 内置模拟支付（测试用） |
| `distribution` | `agent_level`, `balance`, `parent_openid`, `referee_count` |
| `config` | app_configs 的 `config_key/config_value/category/is_public`, splash_screens 的 `is_active/image_url`, banners 的 `image_url` |

### 特殊情况

- **`product_skus` 无数据**：SQL dump 中有表结构但无数据行，cart 云函数已做降级处理（从 products 取价格和图片）
- **`payment` 模拟支付**：测试阶段直接标记 `status='pending_ship'`，正式上线前需替换为 `cloud.cloudPay.unifiedOrder()`
