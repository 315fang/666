'use strict';
const cloud = require('wx-server-sdk');

/**
 * 生成微信支付预支付信息
 */
async function generatePrepayInfo(orderId, amount, description) {
    const timestamp = Math.floor(Date.now() / 1000);
    const nonceStr = Math.random().toString(36).substring(2, 15);

    return {
        appId: process.env.WX_APP_ID,
        timeStamp: timestamp,
        nonceStr: nonceStr,
        package: 'prepay_id=WX_PREPAY_ID',
        signType: 'RSA',
        paySign: 'SIGNATURE'
    };
}

module.exports = {
    generatePrepayInfo
};
