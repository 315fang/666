'use strict';
const cloud = require('wx-server-sdk');
const db = cloud.database();

/**
 * 申请退款
 */
async function applyRefund(orderId, reason) {
    const order = await db.collection('orders').doc(orderId).get();
    if (!order.data) return { success: false, message: '订单不存在' };

    const result = await db.collection('refunds').add({
        data: {
            order_id: orderId,
            reason: reason,
            status: 'pending',
            created_at: db.serverDate()
        }
    });

    return { success: true, refundId: result._id };
}

module.exports = {
    applyRefund
};
