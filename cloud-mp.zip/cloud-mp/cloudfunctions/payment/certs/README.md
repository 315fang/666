Place WeChat Pay V3 files in this folder.

Expected files:
- apiclient_key.pem
- apiclient_cert.pem
- wechatpay_platform.pem
- wechatpay_pubkey.pem

Supported modes:
- platform certificate mode: use `wechatpay_platform.pem`
- public key mode: use `wechatpay_pubkey.pem`

Do not commit real private keys/certs to git.
