'use strict';
const cloud = require('wx-server-sdk');
const db = cloud.database();

/**
 * 处理微信支付回调
 */
async function handleCallback(event) {
    try {
        const body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const { out_trade_no, trade_state } = body;

        if (trade_state === 'SUCCESS') {
            await db.collection('orders').where({ order_no: out_trade_no }).update({
                data: {
                    status: 'paid',
                    paid_at: db.serverDate(),
                    trade_id: body.transaction_id
                }
            });
            return { code: 'SUCCESS', message: 'Payment processed' };
        }

        return { code: 'FAIL', message: 'Payment failed' };
    } catch (err) {
        console.error('[PaymentCallback]', err);
        return { code: 'FAIL', message: err.message };
    }
}

module.exports = {
    handleCallback
};
