'use strict';
const cloud = require('wx-server-sdk');
const db = cloud.database();

/**
 * 查询订单支付状态
 */
async function queryPaymentStatus(orderId) {
    const order = await db.collection('orders').doc(orderId).get();
    if (!order.data) return null;

    return {
        orderId: order.data._id,
        status: order.data.status,
        amount: order.data.pay_amount,
        paidAt: order.data.paid_at
    };
}

module.exports = {
    queryPaymentStatus
};
