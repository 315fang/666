'use strict';
const cloud = require('wx-server-sdk');
const db = cloud.database();

/**
 * 获取用户优惠券列表
 */
async function listCoupons(openid, status = 'unused') {
    const query = { openid };
    if (status) query.status = status;

    const res = await db.collection('user_coupons')
        .where(query)
        .orderBy('expire_at', 'asc')
        .get();
    return res.data || [];
}

/**
 * 领取优惠券
 */
async function claimCoupon(openid, couponId) {
    const existing = await db.collection('user_coupons')
        .where({ openid, coupon_id: couponId })
        .limit(1)
        .get();

    if (existing.data && existing.data.length > 0) {
        return { success: false, message: '已领取此优惠券' };
    }

    const coupon = await db.collection('coupons').doc(couponId).get();
    if (!coupon.data) {
        return { success: false, message: '优惠券不存在' };
    }

    const result = await db.collection('user_coupons').add({
        data: {
            openid,
            coupon_id: couponId,
            coupon_name: coupon.data.name,
            status: 'unused',
            created_at: db.serverDate(),
            expire_at: db.serverDate({ offset: (coupon.data.valid_days || 30) * 24 * 60 * 60 })
        }
    });

    return { success: true, id: result._id };
}

module.exports = {
    listCoupons,
    claimCoupon
};
