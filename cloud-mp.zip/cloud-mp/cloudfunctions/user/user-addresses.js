'use strict';
const cloud = require('wx-server-sdk');
const db = cloud.database();

/**
 * 获取用户地址列表
 */
async function listAddresses(openid) {
    const res = await db.collection('addresses')
        .where({ openid })
        .get();
    return res.data || [];
}

/**
 * 添加地址
 */
async function addAddress(openid, addressData) {
    const result = await db.collection('addresses').add({
        data: {
            openid,
            created_at: db.serverDate(),
            updated_at: db.serverDate(),
            ...addressData
        }
    });
    return result;
}

/**
 * 更新地址
 */
async function updateAddress(addressId, addressData) {
    await db.collection('addresses').doc(addressId).update({
        data: {
            updated_at: db.serverDate(),
            ...addressData
        }
    });
    return db.collection('addresses').doc(addressId).get();
}

/**
 * 删除地址
 */
async function deleteAddress(addressId) {
    await db.collection('addresses').doc(addressId).remove();
    return { success: true };
}

module.exports = {
    listAddresses,
    addAddress,
    updateAddress,
    deleteAddress
};
