'use strict';
const cloud = require('wx-server-sdk');
const db = cloud.database();

/**
 * 获取用户信息
 */
async function getProfile(openid) {
    const res = await db.collection('users').where({ openid }).limit(1).get();
    return res.data[0] || null;
}

/**
 * 更新用户信息
 */
async function updateProfile(openid, data) {
    const updateData = {
        updated_at: db.serverDate(),
        ...data
    };
    await db.collection('users').where({ openid }).update({ data: updateData });
    return getProfile(openid);
}

module.exports = {
    getProfile,
    updateProfile
};
