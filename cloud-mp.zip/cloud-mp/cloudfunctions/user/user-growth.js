'use strict';
const cloud = require('wx-server-sdk');
const db = cloud.database();
const { buildGrowthProgress, loadTierConfig } = require('../shared/growth');

/**
 * 获取成长进度
 */
async function getGrowthProgress(openid) {
    const user = await db.collection('users').where({ openid }).limit(1).get();
    if (!user.data.length) return null;

    const points = user.data[0].points || user.data[0].growth_value || 0;
    const tierConfig = await loadTierConfig();
    return buildGrowthProgress(points, tierConfig);
}

/**
 * 增加积分
 */
async function addPoints(openid, points) {
    const user = await db.collection('users').where({ openid }).limit(1).get();
    if (!user.data.length) return null;

    const currentPoints = (user.data[0].points || 0) + points;
    await db.collection('users').where({ openid }).update({
        data: {
            points: currentPoints,
            growth_value: currentPoints,
            updated_at: db.serverDate()
        }
    });

    return getGrowthProgress(openid);
}

module.exports = {
    getGrowthProgress,
    addPoints
};
