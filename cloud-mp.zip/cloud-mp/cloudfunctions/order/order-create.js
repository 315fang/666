'use strict';
const cloud = require('wx-server-sdk');
const db = cloud.database();

/**
 * 创建订单
 */
async function createOrder(openid, orderData) {
    const orderNo = 'ORD' + Date.now();
    
    const order = {
        order_no: orderNo,
        openid: openid,
        status: 'pending_payment',
        items: orderData.items || [],
        total_amount: orderData.total_amount,
        pay_amount: orderData.pay_amount,
        created_at: db.serverDate(),
        updated_at: db.serverDate()
    };

    const result = await db.collection('orders').add({ data: order });
    return { success: true, orderId: result._id, orderNo };
}

module.exports = {
    createOrder
};
