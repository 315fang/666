'use strict';
const cloud = require('wx-server-sdk');
const db = cloud.database();

/**
 * 查询用户订单
 */
async function queryOrders(openid, status = null) {
    let query = db.collection('orders').where({ openid });
    
    if (status) {
        query = query.where({ status });
    }

    const res = await query.orderBy('created_at', 'desc').get();
    return res.data || [];
}

/**
 * 获取订单详情
 */
async function getOrderDetail(orderId, openid) {
    const order = await db.collection('orders').doc(orderId).get();
    
    if (!order.data || order.data.openid !== openid) {
        return null;
    }

    return order.data;
}

module.exports = {
    queryOrders,
    getOrderDetail
};
