'use strict';
const cloud = require('wx-server-sdk');
const db = cloud.database();

/**
 * 更新订单状态
 */
async function updateOrderStatus(orderId, newStatus) {
    await db.collection('orders').doc(orderId).update({
        data: {
            status: newStatus,
            updated_at: db.serverDate()
        }
    });
    return { success: true };
}

module.exports = {
    updateOrderStatus
};
