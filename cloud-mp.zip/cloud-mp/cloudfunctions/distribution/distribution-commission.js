'use strict';
const cloud = require('wx-server-sdk');
const db = cloud.database();

/**
 * 计算佣金
 */
async function calculateCommission(orderId) {
    const order = await db.collection('orders').doc(orderId).get();
    if (!order.data) return 0;

    const amount = order.data.pay_amount || 0;
    const commissionRate = 0.1; // 10%
    return Math.round(amount * commissionRate * 100) / 100;
}

/**
 * 结算佣金
 */
async function settleCommission(openid, amount) {
    await db.collection('users').where({ openid }).update({
        data: {
            wallet_balance: db.command.inc(amount),
            updated_at: db.serverDate()
        }
    });
    return { success: true };
}

module.exports = {
    calculateCommission,
    settleCommission
};
