'use strict';
const cloud = require('wx-server-sdk');
const db = cloud.database();

/**
 * 查询分销数据
 */
async function queryDistribution(openid) {
    const user = await db.collection('users').where({ openid }).limit(1).get();
    if (!user.data.length) return null;

    const distLevel = user.data[0].distributor_level || 0;
    const balance = user.data[0].wallet_balance || 0;

    return {
        level: distLevel,
        balance: balance,
        totalCommission: 0,
        status: distLevel > 0 ? 'active' : 'inactive'
    };
}

module.exports = {
    queryDistribution
};
