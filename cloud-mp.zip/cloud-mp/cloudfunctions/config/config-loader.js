'use strict';
const cloud = require('wx-server-sdk');
const db = cloud.database();

/**
 * 加载配置
 */
async function loadConfig(configType) {
    const res = await db.collection('configs')
        .where({ type: configType, active: true })
        .limit(1)
        .get();
    
    return res.data && res.data.length > 0 ? res.data[0] : null;
}

/**
 * 加载所有配置
 */
async function loadAllConfigs() {
    const res = await db.collection('configs')
        .where({ active: true })
        .get();
    
    return res.data || [];
}

module.exports = {
    loadConfig,
    loadAllConfigs
};
