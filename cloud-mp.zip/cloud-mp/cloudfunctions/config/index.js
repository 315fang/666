'use strict';
'use strict';
const cloud = require('wx-server-sdk');

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

const db = cloud.database();
const _ = db.command;

// ==================== 共享模块导入 ====================
const {
    validateAction, validateAmount, validateInteger, validateString,
    validateArray, validateRequiredFields
} = require('../shared/validators');
const {
    CloudBaseError, ERROR_CODES, errorHandler, cloudFunctionWrapper
} = require('../shared/errors');
const {
    success, error, paginated, list, created, updated, deleted,
    badRequest, unauthorized, forbidden, notFound, conflict, serverError
} = require('../shared/response');
const {
    DEFAULT_GROWTH_TIERS, calculateTier, buildGrowthProgress, loadTierConfig
} = require('../shared/growth');

// ==================== 云初始化 ====================


function isEnabledFlag(value) {
    return value === true || value === 1 || value === '1' || value === 'active' || value === 'on_sale';
}

function isWithinActivityWindow(item, now = Date.now()) {
    const startAt = item && item.start_at ? new Date(item.start_at).getTime() : NaN;
    const endAt = item && item.end_at ? new Date(item.end_at).getTime() : NaN;
    const startsOk = Number.isNaN(startAt) || startAt <= now;
    const endsOk = Number.isNaN(endAt) || endAt > now;
    return startsOk && endsOk;
}

async function getSingletonDoc(collectionName) {
    const res = await db.collection(collectionName).limit(1).get().catch(() => ({ data: [] }));
    return res.data[0] || null;
}

async function getMiniProgramConfig() {
    const directDoc = await getSingletonDoc('mini-program-config');
    if (directDoc) return directDoc;

    const appConfigs = await db.collection('app_configs')
        .where({ is_public: true, status: _.in([true, 1, '1']) })
        .limit(200)
        .get()
        .catch(() => ({ data: [] }));

    const result = {};
    appConfigs.data.forEach((row) => {
        let value = row.config_value;
        if (row.config_type === 'json' || row.config_type === 'object' || row.config_type === 'array') value = toObject(value, value);
        else if (row.config_type === 'number') value = toNumber(value, 0);
        else if (row.config_type === 'boolean') value = value === 'true' || value === '1';
        if (row.category) {
            if (!result[row.category]) result[row.category] = {};
            result[row.category][row.config_key] = value;
        } else {
            result[row.config_key] = value;
        }
    });
    return result;
}

async function getSettingsConfig() {
    const directDoc = await getSingletonDoc('settings');
    if (directDoc) return directDoc;
    const rows = await db.collection('configs').limit(200).get().catch(() => ({ data: [] }));
    const result = {};
    rows.data.forEach((row) => {
        const group = row.config_group || row.category || 'SYSTEM';
        if (!result[group]) result[group] = {};
        let value = row.config_value;
        try {
            value = JSON.parse(value);
        } catch (_) {}
        result[group][row.config_key] = value;
    });
    return result;
}

function normalizeBanner(item) {
    return {
        id: item._id || item.id,
        title: item.title || '',
        subtitle: item.subtitle || item.kicker || '',
        image_url: item.image_url || item.image || '',
        image: item.image_url || item.image || '',
        link_type: item.link_type || 'none',
        link_value: String(item.link_value || item.product_id || ''),
        position: item.position || 'home',
        sort_order: toNumber(item.sort_order, 0)
    };
}

function normalizeProduct(product) {
    const images = toArray(product.images);
    return {
        id: product._id || product.id,
        name: product.name || '',
        cover_image: product.cover_image || images[0] || '',
        images,
        description: product.description || '',
        retail_price: toNumber(product.retail_price != null ? product.retail_price : product.min_price, 0),
        market_price: toNumber(product.market_price != null ? product.market_price : product.original_price, 0),
        stock: toNumber(product.stock, 0),
        sales_count: toNumber(product.sales_count != null ? product.sales_count : product.purchase_count, 0),
        heat_label: product.heat_label || '',
        status: product.status,
        visible_in_mall: product.visible_in_mall,
        enable_group_buy: product.enable_group_buy
    };
}

async function loadProductsByIds(productIds = []) {
    const rawIds = [...new Set(
        productIds
            .map((item) => String(item == null ? '' : item).trim())
            .filter(Boolean)
    )];

    if (!rawIds.length) return {};

    const numericIds = rawIds
        .map((item) => toNumber(item, NaN))
        .filter((item) => Number.isFinite(item));

    const [byLegacyIds, byDocIds] = await Promise.all([
        numericIds.length
            ? db.collection('products')
                .where({ id: _.in([...new Set(numericIds)]) })
                .limit(Math.min(numericIds.length, 100))
                .get()
                .catch(() => ({ data: [] }))
            : Promise.resolve({ data: [] }),
        Promise.all(rawIds.map((id) =>
            db.collection('products').doc(id).get().catch(() => ({ data: null }))
        ))
    ]);

    return [...(byLegacyIds.data || []), ...byDocIds.map((item) => item.data).filter(Boolean)].reduce((acc, item) => {
        const key = String(item.id != null ? item.id : item._id);
        acc[key] = normalizeProduct(item);
        if (item.id != null) acc[String(item.id)] = normalizeProduct(item);
        if (item._id != null) acc[String(item._id)] = normalizeProduct(item);
        return acc;
    }, {});
}

async function loadActivityList(collectionName, formatter = null, options = {}) {
    const { productId } = options;
    const res = await db.collection(collectionName)
        .orderBy('created_at', 'desc')
        .limit(100)
        .get()
        .catch(() => ({ data: [] }));

    const rows = (Array.isArray(res.data) ? res.data : []).filter((item) => {
        const enabled = isEnabledFlag(item?.status) || isEnabledFlag(item?.is_active);
        if (!enabled) return false;
        if (!isWithinActivityWindow(item)) return false;
        if (productId == null || productId === '') return true;
        return String(item.product_id) === String(productId);
    });
    const productsById = await loadProductsByIds(rows.map((item) => item.product_id));

    return rows.map((item) => {
        const normalized = formatter ? formatter(item) : { ...item, id: item._id || item.id };
        const productKey = String(item.product_id != null ? item.product_id : '');
        return {
            ...normalized,
            product: productsById[productKey] || null
        };
    });
}

async function getActiveProducts(limit = 6) {
    const query = await db.collection('products')
        .where({ status: _.in([true, 1, '1', 'active', 'on_sale']) })
        .orderBy('manual_weight', 'desc')
        .limit(limit)
        .get()
        .catch(() => ({ data: [] }));
    return query.data.map(normalizeProduct);
}

exports.main = async (event) => {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;
    const { action } = event;

    // 基本action验证
    const ALLOWED_ACTIONS = ['login', 'miniProgramConfig', 'getPaymentConfig', 'getDistributionConfig'];
    if (action && !ALLOWED_ACTIONS.includes(action)) {
        return error(400, `Invalid action: ${action}. Must be one of: ${ALLOWED_ACTIONS.join(', ')}`);
    }

    const { action } = event;
    const wxContext = cloud.getWXContext();
    const currentOpenid = wxContext.OPENID;

    if (action === 'miniProgramConfig') {
        return success(await getMiniProgramConfig() );
    }

    if (action === 'homeContent') {
        const [miniProgramConfig, bannersRes, featuredProducts] = await Promise.all([
            getMiniProgramConfig(),
            db.collection('banners')
                .where({ status: _.in([true, 1, '1']) })
                .orderBy('sort_order', 'asc')
                .limit(20)
                .get()
                .catch(() => ({ data: [] })),
            getActiveProducts(6)
        ]);

        const bannersByPosition = { home: [], home_mid: [], home_bottom: [], category: [] };
        bannersRes.data.map(normalizeBanner).forEach((item) => {
            const position = item.position || 'home';
            if (!bannersByPosition[position]) bannersByPosition[position] = [];
            bannersByPosition[position].push(item);
        });

        // 从 app_configs 中提取活动链接配置，供活动页面使用
        const activityLinks = miniProgramConfig.activity && miniProgramConfig.activity.activity_links_config
            ? miniProgramConfig.activity.activity_links_config
            : miniProgramConfig.activity_links_config || null;

        return success({
                banners: bannersByPosition.home),
                _resources: {
                    layoutSchema: [],
                    dataSources: {},
                    banners: bannersByPosition,
                    boards: { 'home.featuredProducts': { products: featuredProducts } }
                }
            },
            resources: {
                legacy_payload: { banners: bannersByPosition.home, configs: miniProgramConfig },
                layout: null,
                boards: { 'home.featuredProducts': { products: featuredProducts } },
                banners: bannersByPosition,
                activity_links: activityLinks
            }
        };
    }

    if (action === 'splash') {
        const res = await db.collection('splash_screens').where({ is_active: true }).limit(1).get().catch(() => ({ data: [] }));
        if (!res.data.length) return success(null );
        const item = res.data[0];
        return success({
                show_mode: item.show_mode || 'image')
        };
    }

    if (action === 'activeTheme') {
        const settings = await getSettingsConfig();
        return success(settings.theme || settings.THEME || {) };
    }

    if (action === 'getSystemConfig') {
        const settings = await getSettingsConfig();
        if (event.key) {
            const result = {};
            Object.keys(settings).forEach((group) => {
                if (settings[group] && Object.prototype.hasOwnProperty.call(settings[group], event.key)) {
                    result[event.key] = settings[group][event.key];
                }
            });
            return success(result );
        }
        if (event.group) return success(settings[event.group] || {) };
        return success(settings );
    }

    // ── 活动列表 ────────────────────────────────
    if (action === 'activities') {
        const res = await db.collection('activities')
            .where({ status: _.in([true, 1, '1', 'active']) })
            .orderBy('created_at', 'desc')
            .limit(20)
            .get()
            .catch(() => ({ data: [] }));
        return success(res.data.map((item) => ({ ...item))) };
    }

    // ── 拼团列表 ────────────────────────────────
    if (action === 'groups') {
        const res = await db.collection('group_activities')
            .where({ status: _.in([true, 1, '1', 'active']) })
            .orderBy('created_at', 'desc')
            .limit(20)
            .get()
            .catch(() => ({ data: [] }));
        return success({
                list: res.data.map((item) => ({
                    ...item))),
                total: res.data.length
            }
        };
    }

    // ── 拼团详情 ────────────────────────────────
    if (action === 'groupDetail') {
        const groupId = event.group_id;
        if (!groupId) return { code: 400, success: false, message: '缺少拼团ID' };
        const [byDocId, byLegacyId] = await Promise.all([
            db.collection('group_activities').doc(String(groupId)).get().catch(() => ({ data: null })),
            db.collection('group_activities').where({ id: toNumber(groupId, NaN) }).limit(1).get().catch(() => ({ data: [] }))
        ]);
        const item = byDocId.data || byLegacyId.data[0] || null;
        if (!item) return { code: 404, success: false, message: '拼团不存在' };
        return success({
                ...item)
        };
    }

    // ── 砍价列表 ────────────────────────────────
    if (action === 'slashList') {
        const res = await db.collection('slash_activities')
            .where({ status: _.in([true, 1, '1', 'active']) })
            .orderBy('created_at', 'desc')
            .limit(20)
            .get()
            .catch(() => ({ data: [] }));
        return success({
                list: res.data.map((item) => ({
                    ...item))),
                total: res.data.length
            }
        };
    }

    // ── 砍价详情 ────────────────────────────────
    if (action === 'slashDetail') {
        const slashId = event.slash_id;
        if (!slashId) return { code: 400, success: false, message: '缺少砍价ID' };
        // 优先从 slash_records 查询（砍价记录详情）
        const [recordByDocId, recordByNo] = await Promise.all([
            db.collection('slash_records').doc(String(slashId)).get().catch(() => ({ data: null })),
            db.collection('slash_records').where({ slash_no: String(slashId) }).limit(1).get().catch(() => ({ data: [] }))
        ]);
        const record = recordByDocId.data || recordByNo.data[0] || null;
        if (record) {
            // 找到记录了，补充活动详情
            const activityId = record.activity_id;
            let activity = null;
            let product = null;
            if (activityId) {
                const [actByDocId, actByLegacyId] = await Promise.all([
                    db.collection('slash_activities').doc(String(activityId)).get().catch(() => ({ data: null })),
                    db.collection('slash_activities').where({ id: toNumber(activityId, NaN) }).limit(1).get().catch(() => ({ data: [] }))
                ]);
                activity = actByDocId.data || actByLegacyId.data[0] || null;
                if (activity?.product_id) {
                    const prodRes = await db.collection('products').where({ _id: String(activity.product_id) }).limit(1).get().catch(() => ({ data: [] }));
                    const prodAlt = await db.collection('products').where({ id: toNumber(activity.product_id, NaN) }).limit(1).get().catch(() => ({ data: [] }));
                    const prod = prodRes.data[0] || prodAlt.data[0] || null;
                    if (prod) {
                        const images = toArray(prod.images);
                        product = { id: prod._id || prod.id, name: prod.name || '', images, retail_price: toNumber(prod.retail_price, 0) };
                    }
                }
            }
            const helpers = toArray(record.helpers);
            const originalPrice = toNumber(activity?.original_price || activity?.retail_price || record.original_price, 0);
            const floorPrice = toNumber(activity?.target_price || activity?.floor_price || record.target_price || 0, 0);
            const currentPrice = toNumber(record.current_price, originalPrice);
            const maxHelpers = toNumber(activity?.max_helpers, -1);
            const stockLimit = toNumber(activity?.stock_limit, 0);
            const soldCount = toNumber(activity?.sold_count, 0);
            const remainSeconds = record.expire_at ? Math.max(0, Math.floor((new Date(record.expire_at).getTime() - Date.now()) / 1000)) : 0;
            return success({
                    ...record) : null
                }
            };
        }
        // 兜底：从 slash_activities 查询（活动详情，而非砍价记录）
        const [byDocId, byLegacyId] = await Promise.all([
            db.collection('slash_activities').doc(String(slashId)).get().catch(() => ({ data: null })),
            db.collection('slash_activities').where({ id: toNumber(slashId, NaN) }).limit(1).get().catch(() => ({ data: [] }))
        ]);
        const item = byDocId.data || byLegacyId.data[0] || null;
        if (!item) return { code: 404, success: false, message: '砍价不存在' };
        return success({
                ...item)
        };
    }

    // ── 抽奖活动配置 ──────────────────────────────
    if (action === 'lottery') {
        const res = await db.collection('lottery_configs')
            .where({ is_active: _.in([true, 1, '1']) })
            .orderBy('created_at', 'desc')
            .limit(1)
            .get()
            .catch(() => ({ data: [] }));
        const config = res.data[0] || null;
        if (!config) return success({ status: 0) };
        return success({
                ...config)
        };
    }

    if (action === 'lotteryPrizes') {
        const query = { is_active: _.in([true, 1, '1']) };
        const res = await db.collection('lottery_prizes').where(query)
            .orderBy('sort_order', 'asc').limit(20).get().catch(() => ({ data: [] }));
        return success(res.data );
    }

    if (action === 'lotteryRecords') {
        const openid = currentOpenid;
        const page = toNumber(event.page, 1);
        const limit = Math.min(toNumber(event.limit, 10), 50);
        if (!openid) return success({ list: []) };
        const countRes = await db.collection('lottery_records').where({ openid }).count().catch(() => ({ total: 0 }));
        const res = await db.collection('lottery_records').where({ openid })
            .orderBy('created_at', 'desc').skip((page - 1) * limit).limit(limit).get().catch(() => ({ data: [] }));
        return success({ list: res.data) };
    }

    if (action === 'boardsMap') {
        const keyList = String(event.keys || '').split(',').filter(Boolean);
        const result = {};
        const featuredProducts = await getActiveProducts(6);
        keyList.forEach((key) => {
            result[key] = { products: key === 'home.featuredProducts' ? featuredProducts : [] };
        });
        return success(result );
    }

    if (action === 'banners') {
        const query = { status: _.in([true, 1, '1']) };
        if (event.position) query.position = event.position;
        const res = await db.collection('banners').where(query).orderBy('sort_order', 'asc').limit(20).get().catch(() => ({ data: [] }));
        return success(res.data.map(normalizeBanner) );
    }

    // ── 活动气泡 ────────────────────────────────
    if (action === 'activityBubbles') {
        const res = await db.collection('activity_bubbles')
            .where({ status: _.in([true, 1, '1']) })
            .orderBy('sort_order', 'asc')
            .limit(10)
            .get()
            .catch(() => ({ data: [] }));
        return success(res.data.map((item) => ({ ...item))) };
    }

    // ── 活动链接 ────────────────────────────────
    if (action === 'activityLinks') {
        const res = await db.collection('activity_links')
            .where({ status: _.in([true, 1, '1']) })
            .orderBy('sort_order', 'asc')
            .limit(100)
            .get()
            .catch(() => ({ data: [] }));
        const allLinks = res.data.map((item) => ({ ...item, id: item._id || item.id }));
        // 按 section 分组返回结构化对象，匹配 activityLoader 期望的格式
        const banners = allLinks.filter((item) => item.section === 'banner' || item.position === 'banner');
        const permanent = allLinks.filter((item) => item.section === 'permanent' || item.position === 'permanent' || item.type === 'permanent');
        const limited = allLinks.filter((item) => item.section === 'limited' || item.position === 'limited' || item.type === 'limited');
        const brandNews = allLinks.filter((item) => item.section === 'brand_news' || item.position === 'brand_news' || item.type === 'brand_news');
        return success({
                banners)
        };
    }

    // ── 节日活动配置 ──────────────────────────────
    if (action === 'festivalConfig') {
        const res = await db.collection('festival_configs')
            .where({ is_active: _.in([true, 1, '1']) })
            .orderBy('created_at', 'desc')
            .limit(1)
            .get()
            .catch(() => ({ data: [] }));
        const config = res.data[0] || null;
        return success(config ? { ...config) : null };
    }

    // ── 规则页面 ────────────────────────────────
    if (action === 'rules') {
        const doc = await getSingletonDoc('rules');
        return success(doc || { title: '平台规则') };
    }

    // ── 问卷 ────────────────────────────────────
    if (action === 'questionnaireActive') {
        const res = await db.collection('questionnaires')
            .where({ is_active: _.in([true, 1, '1']) })
            .orderBy('created_at', 'desc')
            .limit(1)
            .get()
            .catch(() => ({ data: [] }));
        return success(res.data[0] || null );
    }

    // ── 拼团活动列表 ──────────────────────────────
    if (action === 'groupActivities') {
        const productId = event.product_id != null && event.product_id !== '' ? String(event.product_id) : '';
        const list = await loadActivityList(
            'group_activities',
            (item) => ({ ...item, id: item._id || item.id }),
            { productId }
        );
        return success(list );
    }

    // ── 砍价活动列表 ──────────────────────────────
    if (action === 'slashActivities') {
        const productId = event.product_id != null && event.product_id !== '' ? String(event.product_id) : '';
        const list = await loadActivityList(
            'slash_activities',
            (item) => ({ ...item, id: item._id || item.id }),
            { productId }
        );
        return success(list );
    }

    // ── 限时抢购详情 ──────────────────────────────
    if (action === 'limitedSpotDetail') {
        const cardId = event.card_id;
        if (!cardId) return success(null );
        const res = await db.collection('flash_sale_cards')
            .where({ _id: cardId }).limit(1).get().catch(() => ({ data: [] }));
        const altRes = !res.data.length
            ? await db.collection('limited_spot_cards').where({ id: toNumber(cardId, NaN) }).limit(1).get().catch(() => ({ data: [] }))
            : { data: [] };
        const card = res.data[0] || altRes.data[0] || null;
        return success(card ? { ...card) : null };
    }

    // ── 品牌动态详情 ──────────────────────────────
    if (action === 'brandNews') {
        const newsId = event.id;
        if (!newsId) return success(null );
        const res = await db.collection('brand_news')
            .where({ _id: String(newsId) }).limit(1).get().catch(() => ({ data: [] }));
        const altRes = !res.data.length
            ? await db.collection('page_contents').where({ _id: String(newsId) }).limit(1).get().catch(() => ({ data: [] }))
            : { data: [] };
        const doc = res.data[0] || altRes.data[0] || null;
        return success(doc ? { ...doc) : null };
    }

    // ── N人团邀请卡 ──────────────────────────────
    if (action === 'nInviteCard') {
        const leaderId = event.leader_id;
        if (!leaderId) return success(null );
        const users = await db.collection('users')
            .where({ openid: String(leaderId) }).limit(1).get().catch(() => ({ data: [] }));
        const user = users.data[0] || null;
        if (!user) return success(null );
        return success({
                leader_openid: user.openid)
        };
    }

    return { code: 400, success: false, message: `未知 action: ${action}` };
};
