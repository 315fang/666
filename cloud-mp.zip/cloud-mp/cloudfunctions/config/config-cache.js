'use strict';

let configCache = {};
let cacheTime = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5分钟

/**
 * 从缓存获取配置
 */
function getCachedConfig(key) {
    const now = Date.now();
    if (now - cacheTime > CACHE_DURATION) {
        configCache = {};
        return null;
    }
    return configCache[key] || null;
}

/**
 * 设置缓存
 */
function setCachedConfig(key, value) {
    configCache[key] = value;
    cacheTime = Date.now();
}

/**
 * 清除缓存
 */
function clearConfigCache() {
    configCache = {};
    cacheTime = 0;
}

module.exports = {
    getCachedConfig,
    setCachedConfig,
    clearConfigCache
};
