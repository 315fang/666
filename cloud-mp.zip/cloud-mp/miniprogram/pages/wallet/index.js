// pages/wallet/index.js
const { get, post } = require('../../utils/request');

Page({
    data: {
        balance: '0.00',
        pendingIn: '0.00',
        commissionOverview: null,
        logs: [],
        logsLoading: true,
        showWithdraw: false,
        withdrawAmount: ''
    },

    onReady() {
        this.brandAnimation = this.selectComponent('#brandAnimation');
    },

    onShow() {
        this.loadWalletInfo();
        this.loadLogs();
    },

    async loadWalletInfo() {
        try {
            const res = await get('/wallet/info');
            if (res.code === 0) {
                const overview = res.data.commission || {};
                this.setData({
                    balance: (res.data.balance || 0).toFixed(2),
                    pendingIn: (res.data.pendingIn || 0).toFixed(2),
                    commissionOverview: {
                        total: overview.total ? overview.total.toFixed(2) : '0.00',
                        frozen: overview.frozen ? overview.frozen.toFixed(2) : '0.00',
                        pendingIn: overview.pendingIn ? overview.pendingIn.toFixed(2) : '0.00',
                        approved: overview.approved ? overview.approved.toFixed(2) : '0.00',
                        available: overview.available ? overview.available.toFixed(2) : '0.00'
                    }
                });
            }
        } catch (err) {
            console.error(err);
        }
    },

    async loadLogs() {
        try {
            const res = await get('/wallet/commissions');
            if (res.code === 0) {
                const logs = (res.data.list || []).map(item => {
                    return {
                        ...item,
                        typeName: this.getTypeName(item.type),
                        statusText: this.getStatusText(item.status),
                        created_at: item.created_at ? item.created_at.replace('T', ' ').substring(0, 19) : '',
                        refund_deadline: item.refund_deadline ? item.refund_deadline.split('T')[0] : null
                    };
                });
                this.setData({ logs, logsLoading: false });
            }
        } catch (err) {
            console.error(err);
            this.setData({ logsLoading: false });
        }
    },

    getTypeName(type) {
        const typeMap = {
            'direct': '直推佣金',
            'Direct': '直推佣金',
            'indirect': '团队佣金',
            'Indirect': '团队佣金',
            'gap': '级差利润',
            'Stock_Diff': '级差利润',
            'agent_fulfillment': '发货利润',
            'self': '自购返利',
            'withdrawal': '提现申请',
            'admin_adjustment': '系统调整'
        };
        return typeMap[type] || type;
    },

    getStatusText(status) {
        const statusMap = {
            'frozen': '冻结中(T+15)',
            'pending_approval': '待审核',
            'approved': '待结算',
            'settled': '已结算',
            'available': '可提现',
            'pending': '待入账',
            'completed': '已完成',
            'rejected': '已驳回',
            'failed': '已失败',
            'cancelled': '已取消'
        };
        return statusMap[status] || status;
    },

    onWithdrawInput(e) {
        this.setData({ withdrawAmount: e.detail.value });
    },

    onWithdrawTap() {
        this.setData({ showWithdraw: true });
    },

    hideWithdraw() {
        this.setData({ showWithdraw: false });
    },

    async confirmWithdraw() {
        const amount = parseFloat(this.data.withdrawAmount);
        if (!amount || amount <= 0) {
            wx.showToast({ title: '请输入有效金额', icon: 'none' });
            return;
        }

        const balance = parseFloat(this.data.balance);
        if (amount > balance) {
            wx.showToast({ title: '提现金额不能大于余额', icon: 'none' });
            return;
        }

        try {
            const res = await post('/wallet/withdraw', { amount });
            if (res.code === 0) {
                this.hideWithdraw();
                this.loadWalletInfo();

                // 触发提现成功动画
                if (this.brandAnimation) {
                    this.brandAnimation.show('withdraw', { amount: amount.toFixed(2) });
                }
            } else {
                wx.showToast({ title: res.message, icon: 'none' });
            }
        } catch (err) {
            wx.showToast({ title: '申请失败', icon: 'none' });
        }
    }
});
